# Simulation Live Code 1 - Web Development Portfolio

> Untuk membaca instruksi ini dalam Bahasa Indonesia, silakan buka tautan berikut: [Bahasa Indonesia](../readme.md)

This Live Code is designed to evaluate your ability to structure web pages using HTML and style them using CSS.

## Live Code Rules

Before you start, please read and strictly follow these rules:

- **For Remote Students:** You **must** share your screen (select *Desktop* or *Entire Screen*), turn on your camera (*open cam*), and unmute your microphone during the Live Code session.
- **Individual Work:** Work on this challenge independently. Any form of academic dishonesty (such as copying code or discussing with others) will result in a score of **0** for this Live Code.
- **Duration:** You have **90 minutes** to complete all three releases (Release 1 - 3).
- **Development Environment:** You are free to write and test your code in your local text editor of choice (VS Code, Sublime Text, etc.).
- **Allowed References:** You may search external resources like Google, StackOverflow, and MDN Web Docs.
- **Forbidden References:** You are **strictly prohibited** from opening previous task repositories on GitHub, OpenClass challenges, lecture slides, recorded video sessions, or other Hacktiv8 internal materials.
- **Submission:** Submit your work once you are confident in your solution or when the instructor directs you to do so.
- **Re-submission:** If you spot an error after submitting, you may modify your code and re-submit, provided the 90-minute limit has not expired. Make sure your final submission is correct, as no further edits are allowed after the time is up.
- **Grading:** You will be graded based on syntax correctness and the visual match of the final web page output.

---

## Technical Directions

Please implement the following guidelines in your code:

- Use appropriate HTML semantic tags to structure the page (e.g., `<html>`, `<head>`, `<body>`, `<div>`, `<h1>`, `<ul>`, `<li>`, `<table>`, `<form>`, etc.).
- Ensure all HTML tags are opened and closed correctly.
- Use necessary attributes such as `class`, `id`, `src`, `alt`, `href`, `name`, `placeholder`, `required`, etc.
- Apply CSS styles using appropriate selectors (element, class, and ID selectors).
- Use CSS properties to format and design the layout (e.g., `font-family`, `color`, `background-color`, `padding`, `margin`, `text-align`, `width`, `height`, etc.).
- Place your CSS rules either within a `<style>` tag (internal CSS) or link an external CSS file using the `<link>` tag.
- Render images using the `<img>` tag and provide valid paths in the `src` attribute.
- Always include an `alt` attribute for all images to ensure web accessibility.
- Create interactive forms using the `<form>` tag.
- Include form input elements such as text fields (`type="text"`), email fields (`type="email"`), and message textareas (`<textarea>`).
- Implement basic client-side form validation using HTML5 attributes (like `required`).

---

## Submission Instructions

1. Place all your solution files inside the `solutions` folder.
1. Commit your code changes locally on a regular basis.
1. Push your completed assignment to your assigned GitHub Classroom repository before the deadline.

---

## Score Weightage Reminder

As a reminder, here is the grading breakdown for Phase 0:

- **Live Code 1:** 10%
- **Live Code 2:** 20%
- **Live Code 3:** 25%
- **Daily Challenges:** 45%
- **Passing Score for Phase 0:** 61%

---

## Challenges: Portfolio Landing Page

### Restrictions

- Adhere to the general rules discussed during the briefing.

### Objectives

- Solve layout and design problems independently.
- Understand the concept and implementation of HTML tags.
- Understand the concept and implementation of CSS properties.

---

### Release 1: Header Section & Welcome Menu

- Create a landing page containing a top navigation menu.
- Display a prominent welcome message at the center of the viewport.
- Include a profile image, your name, job title (Web Developer), and a short description highlighting your skills and expertise.

**Expected Layout for Release 1:**

![Expected Release 1](../resources/release-1.png)

---

### Release 2: Data Exploration Section (Table)

- Implement a section below the main landing page to display structured data.
- Present this data inside an HTML `<table>`.
- The table must contain at least three columns: **Name**, **Email**, and **Phone Number**.

**Expected Layout for Release 2:**

![Expected Layout for Release 2](../resources/release-2.png)

---

### Release 3: Contact Form & Validation

- Develop a dedicated contact section at the bottom of the page.
- Add a contact form containing the following input fields: **Name**, **Email**, and **Messages**.
- Configure form validation so that all fields are marked as `required`.
- Ensure that appropriate browser error messages are displayed when a user attempts to submit an empty form or enters an invalid email format.

**Expected Layout for Release 3:**

![Expected Layout for Release 3](../resources/release-3.png)

---

### Final Page View (All Releases Combined)

After completing Releases 1, 2, and 3, your portfolio web page should match the layout below:

![All Releases](../resources/all-release.png)

Good luck with the challenge!
