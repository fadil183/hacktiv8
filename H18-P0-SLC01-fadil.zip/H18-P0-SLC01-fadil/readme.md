# Simulasi Live Code 1 - Web Development Portfolio

> To read this instruction in English, please open the following link: [English](i18n/readme-en.md)

Live Code ini dirancang untuk menguji kemampuan kamu dalam menyusun struktur halaman web menggunakan HTML dan menerapkan penataan gaya menggunakan CSS.

## Peraturan Live Code

Sebelum memulai, pastikan kamu memahami dan mematuhi peraturan berikut:

- **Untuk Kampus Remote:** Kamu **wajib** melakukan *share screen* (pilih opsi *Desktop* atau *Entire Screen*), menyalakan kamera (*open cam*), dan mengaktifkan mikrofon (*unmute*) selama Live Code berlangsung.
- **Pekerjaan Individu:** Kerjakan tugas ini secara mandiri. Segala bentuk kecurangan (seperti menyalin kode orang lain atau berdiskusi) akan membuat nilai Live Code kamu menjadi **0**.
- **Waktu Pengerjaan:** Kamu memiliki waktu **90 menit** untuk menyelesaikan seluruh rilis (Release 1 - 3).
- **Alat Kerja:** Kamu diperbolehkan mencoba dan menulis kode di teks editor lokal pilihanmu (VS Code, Sublime Text, dsb.).
- **Referensi yang Diizinkan:** Kamu diperbolehkan membuka referensi eksternal umum seperti Google, StackOverflow, dan MDN Web Docs.
- **Referensi yang Dilarang:** Kamu **dilarang keras** membuka repositori tugas sebelumnya di organisasi GitHub, tantangan OpenClass yang pernah diberikan, slide materi, rekaman video pembelajaran, atau dokumentasi internal Hacktiv8 lainnya.
- **Proses Submit:** Lakukan pengumpulan (*submit*) pekerjaan jika kamu sudah yakin selesai atau saat instruktur meminta untuk mengumpulkan.
- **Re-submit:** Jika setelah mengumpulkan kamu menemukan kesalahan, kamu masih boleh memperbaiki kode dan mengumpulkan ulang (*re-submit*), asalkan waktu pengerjaan masih tersisa. Pastikan versi terakhir yang kamu kirim sudah benar karena setelah waktu habis, kamu tidak bisa mengumpulkan lagi.
- **Penilaian:** Evaluasi akan didasarkan pada ketepatan sintaksis kode dan kesesuaian hasil akhir tampilan halaman web.

---

## Petunjuk Teknis Pengerjaan

Perhatikan dan terapkan ketentuan berikut di dalam kodemu:

- Gunakan tag HTML yang tepat untuk membangun struktur halaman (seperti `<html>`, `<head>`, `<body>`, `<div>`, `<h1>`, `<ul>`, `<li>`, `<table>`, `<form>`, dll.).
- Pastikan semua tag HTML dibuka dan ditutup dengan benar.
- Gunakan atribut HTML yang diperlukan (seperti `class`, `id`, `src`, `alt`, `href`, `name`, `placeholder`, `required`, dll.).
- Terapkan gaya CSS menggunakan selektor yang sesuai (selektor tag/elemen, selektor class, dan selektor ID).
- Gunakan properti CSS untuk memperindah tampilan (seperti `font-family`, `color`, `background-color`, `padding`, margin, `text-align`, `width`, `height`, dll.).
- Tulis kode CSS di dalam tag `<style>` (internal CSS) atau di file CSS eksternal terpisah yang dihubungkan menggunakan tag `<link>`.
- Tampilkan gambar menggunakan tag `<img>` dan berikan nilai atribut `src` yang valid.
- Selalu berikan atribut `alt` pada setiap gambar untuk kebutuhan aksesibilitas (*accessibility*).
- Buat formulir interaktif menggunakan tag `<form>`.
- Sediakan elemen input formulir yang sesuai, seperti input teks (`type="text"`), email (`type="email"`), dan area pesan (`<textarea>`).
- Terapkan validasi input formulir bawaan menggunakan atribut HTML5 (seperti `required`).

---

## Petunjuk Pengumpulan Tugas

1. Masukkan semua berkas jawaban kamu ke dalam folder `solutions`.
1. Lakukan *commit* secara berkala pada repositori lokal kamu.
1. Unggah (*push*) seluruh file hasil pekerjaan kamu ke repositori GitHub Classroom masing-masing sebelum batas waktu yang ditentukan.

---

## Informasi Bobot Nilai

Sebagai pengingat, berikut adalah kontribusi nilai Phase 0:

- **Live Code 1:** 10%
- **Live Code 2:** 20%
- **Live Code 3:** 25%
- **Tantangan Harian (Daily Challenges):** 45%
- **Nilai Kelulusan (Passing Score Phase 0):** 61%

---

## Soal Tantangan: Landing Page Portofolio

### Batasan (Restrictions)

- Ikuti semua aturan umum yang telah disampaikan saat briefing.

### Target Pembelajaran (Objectives)

- Mampu menyelesaikan masalah tata letak web secara mandiri.
- Memahami konsep dan implementasi tag HTML.
- Memahami konsep dan implementasi properti CSS.

---

### Rilis 1 (Release 1): Halaman Utama & Menu

- Buat halaman landing page lengkap dengan menu navigasi di bagian atas.
- Tampilkan pesan selamat datang (*welcome message*) tepat di tengah halaman.
- Sertakan foto profil, nama lengkap, profesi (web developer), serta deskripsi singkat mengenai keahlian (*skills*) yang kamu miliki.

**Ekspektasi Tampilan Release 1:**

![Ekspektasi Release 1](resources/release-1.png)

---

### Rilis 2 (Release 2): Section Data Keahlian/Tim

- Tambahkan bagian (*section*) baru di bawah halaman utama untuk menampilkan data.
- Sajikan data tersebut menggunakan elemen tabel (`<table>`).
- Tabel harus memiliki kolom minimal: **Nama (Name)**, **Email**, dan **Nomor Telepon (Phone Number)**.

**Ekspektasi Tampilan Release 2:**

![Ekspektasi Release 2](resources/release-2.png)

---

### Rilis 3 (Release 3): Formulir Kontak & Validasi

- Tambahkan bagian kontak (*contact section*) di bagian bawah halaman.
- Buat sebuah formulir kontak (*contact form*) yang memiliki input: **Nama (Name)**, **Email**, dan **Pesan (Messages)**.
- Terapkan validasi formulir agar semua kolom wajib diisi sebelum dikirim (`required`).
- Pastikan browser menampilkan pesan eror atau peringatan bawaan jika pengguna mencoba mengirimkan formulir yang kosong atau format emailnya tidak valid.

**Ekspektasi Tampilan Release 3:**

![Ekspektasi Release 3](resources/release-3.png)

---

### Hasil Akhir Halaman (Seluruh Rilis)

Setelah menyelesaikan Rilis 1, 2, dan 3, halaman web portofolio kamu secara keseluruhan harus terlihat seperti ini:

![Semua Release](resources/all-release.png)

Selamat mengerjakan dan semoga sukses!
